
Design Pattern: MVP is used.

Presenter classes represents the medium for communication between Views and Models classes.
Presenter classes maintains the buisness logic.
Model classes hold the data fetched from API's.
View classes are used for user's interaction.
View classes represents the data to the user.   